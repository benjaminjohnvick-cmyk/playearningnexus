# PlayEarning Nexus — Changes Summary

## 2026-07-30 — New features + platform-wide cost levers

**Five features (all prebuilt, ON by default):**
- **Tiered survey rewards** — non-premium earn 12 points per $1 of survey value; premium (PPC) earn 24%
  cash back; the store unlocks at $8/day of gross survey value. BitLabs cash is kept by the platform.
- **Services marketplace section** — full parity with the other sections + the App Store: serverless-GPU
  category tiles, subsections, and search (`serviceStoreCategories`, `aiServiceCategoryImages`).
- **Auto-qualify → one-tap Premium** — a user who completes the daily survey goal on enough days
  (`PREMIUM_AUTOQUALIFY_DAYS`, default 260 = 5/wk × 52) is offered a consent-gated, one-tap upgrade
  (`premiumEligibility`, `premiumAcceptOffer`, `PremiumEarnedBanner`).
- **Group goals** — friends work toward a big-ticket item with NO shared wallet: each keeps their own
  points, the platform sums individual progress and funds a capped reward at the shared milestone
  (`createGroupGoal`/`joinGroupGoal`/`groupGoalStatus`/`claimGroupGoalReward`; `GroupGoal`,
  `GroupGoalReward` entities). Compliant — value flows platform→member only.
- **Verified surveys** — answer the platform's OWN PPC surveys by typing/dictating (free, phone keyboard
  mic) or by voice recording. Free device transcription first, Whisper only as fallback; a free rules-first
  matcher fills answers, the respondent confirms, an AI validity score + heatmap trace gate the payout.
  **Recordings are transcribed then discarded — never stored** (biometric data minimization). Own PPC
  surveys only, never BitLabs. (`verifiedSurveyConsent`, `transcribeSurveyAudio`,
  `autofillSurveyFromTranscript`, `submitVerifiedSurveyResponse`; `VerifiedSurveyMedia` receipt entity.)

**Cost levers applied across the platform (everything stays ON — pure efficiency):**
- Cheap-model default (Claude aligned to Haiku, matching OpenAI's gpt-4o-mini; heavy sites opt up).
- Rules-first moderation & triage (`sdk/rules-first.ts`) — chat/forum moderation + support/bug triage
  resolve most cases free; AI only for the ambiguous middle.
- Borderline-only AI quality scan (`surveyQualityAutoScan`) — deterministic score resolves clear cases.
- Do-once translation cache (`translateText`) + geo-IP cache (`checkSurveyFraud`) via `sdk/cache.ts`.
- Verified-survey recordings never stored (zero storage, compliance win).
- Voice-input hint (`VoiceInputHint`) — free OS keyboard dictation surfaced on chat inputs.
- Docs: `VERIFIED-SURVEYS.md`, `COST-LEVERS-CODEABLE.md`, `LAUNCH-ESTIMATE-2026-07-30.md`; updated
  `UNDER-5K-EXECUTION-KIT.md`, `backend/.env.example`.

## 2026-07-29 — Automate the kit: continuous deployment, one-click Railway, no-terminal wizard

The execution kit now runs itself and works without a coding agent. See
`deploy-kit/CONTINUOUS-DEPLOYMENT-AND-ONE-CLICK.md`.

- **Continuous deployment** — `.github/workflows/deploy.yml`: every push to `main` validates (build +
  full pre-deploy audit), deploys the backend to Railway, and runs the automated QA smoke. Guarded on a
  `RAILWAY_TOKEN` secret — validates and skips deploy gracefully until set (never hard-fails, no money paths).
- **One-click deploy** — a "Deploy on Railway" button in the README + `backend/railway.json`.
- **No-terminal wizard** — `deploy-kit/wizard/index.html`: 100% in-browser, sends nothing anywhere; paste
  keys → Generate → ready `.env` with the launch defaults pre-filled.
- Mobile builds already push-triggered (`android-release` / `ios-release`).
- Human-only steps unchanged for everyone: account creation, keys/payment, terms, app-store review.

---

## 2026-07-29 — Survey make-up, everything-on defaults, execution kit maxed out

**Survey make-up.** Missed PPC survey days add one extra 8-min session to a later day; the app
recalculates the daily catch-up target (today's + one per missed day) within a ≥1-year window from signup.
`makeupPlan()` + `markSurveyDay(userId, minutes)` credit multiple sessions/day (idempotent, capped);
`premiumPPCStatus.makeup` + `PremiumLockoutMode.jsx` surface it. No debt, no expiry inside the window.

**Everything ON from day one.** `backend/.env.example` rewritten as the everything-on launch config for
the current up-front + advertising + make-up model (removed the contradictory old charge vars). AI/product
flags default ON; only legally-gated switches stay off.

**Execution kit maxed out.** `deploy-kit/validate.sh` now does a full pre-deploy audit (entities↔schema,
scheduler↔functions, manifest); `deploy-kit/e2e-smoke.mjs` is a full automated QA pass (critical path +
new-feature routes); `launch.sh` runs it automatically. UNDER-5K-EXECUTION-KIT.md + COST-AND-DEVHOURS-
LEVERS.md document the honest floor (realistic full-launch dev ≈ $1,050–$1,800).

---

## 2026-07-29 — Premium PPC up-front model, AI advertising + learning, one-tap posting, compliance backstops

**Premium PPC up-front model (points-value-only, closed-loop).** Enrollment grants the full $1,460
(146,000 points) up front for a 1-year ~8-min/day survey commitment; 1:1 matched to $5,000 advertisers who
get $10k perks + $10k social-ad credit and are advertised free until they've doubled ($10k in orders).
Nothing is repaid or clawed back — falling behind only pauses surveys (keep-your-points lockout).
Changed/new: `premiumPPCEnroll`, `premiumPPCStatus`, `premiumPPCSurveyDay`, `premiumPPCOffer`,
`sdk/premium-ppc.ts`; survey-day hook in `processPPCSession`; order-attribution in
`autoOrderFulfillmentAndFundsRelease`; scheduled `daily-premium-ppc-autoadvertise`. See
PREMIUM-PPC-UPFRONT-AND-SOCIAL-ADS.md.

**Lockout mode (in-app).** `premiumPPCSetLockoutTime` + `PremiumLockoutMode.jsx` — member-set daily
in-app survey reminder; required to re-enroll after a default (in-app only).

**AI advertising that learns and self-improves.** `premiumPPCAutoAdvertise` writes #ad-disclosed ads for
each not-yet-doubled advertiser (plus a daily own-business post) to consenting members' connected accounts,
defaulting to member approval. New `sdk/ad-learning.ts` turns every member decision into the same learning
primitives the platform already uses (`OptimizationSignal` + `AgentLearningMemory`, agent `ppc_ad_ai`),
feeding `learningInsights`/`learningDistill`/self-learning — no new tables. Reads signals back to
prioritize platforms + feed exemplars; respects the global `ai_paused` switch; logs each run to the live
oversight feed. See AI-ADVERTISING-AND-LEARNING.md.

**One-tap posting.** `src/lib/socialCompose.js` + `PremiumAdQueue.jsx` — prefilled composer
(X/Reddit/Telegram/WhatsApp), OS native share sheet (Instagram/TikTok/Facebook/LinkedIn), copy+open
fallback. See SOCIAL-POSTING-ONE-TAP-AND-CONSENT.md.

**Compliance backstops (default-safe).** `DAILY_EARN_CAP_USD` wired into `processPPCSession` (clamp via
`allowedEarn` + record `DailyEarnings`); payout reservation released on `failed`/`cancelled` in
`autoPayoutRequestLifecycle`; jurisdiction + 18+ gate added to `awardReferralJackpotEntries`. Confirmed
`AI_DAILY_SPEND_CAP_USD` and `MAINTENANCE_MODE` already wired.

**Still needs counsel:** up-front grant characterization, real-dollar ad claims + points disclaimer,
social posting under each platform's API terms + FTC, 1099 tax treatment.

---

## 2026-07-29 — AI Live Oversight: all-AI-on with user-vote promotion + optional human gate

The autonomous-AI control layer. See `AI-LIVE-OVERSIGHT.md`.

- **All AI on by default.** Every AI engine runs from the get-go (`kyc_survey_ai_autopublish` → ON).
- **Per-user consent → statistical approval → global.** Each non-sensitive AI change is put to real
  users as a yes/no; only changes with a high statistical approval bar (min votes + min yes-rate +
  Wilson 95% lower-bound) are promoted. `OPTIMIZER_REQUIRE_EXPERIMENT` on; `evaluateExperiments` + the
  vote prompt (already mounted) drive it.
- **AI self-review by default; human review optional.** With `AI_GLOBAL_HUMAN_GATE` OFF (default), the
  AI reviews the user-approved change (`aiReviewPromotion`) and promotes it site-wide. Flip the gate ON
  to route promotions to a once-per-24h, one-hour peak-time human window (`aiGlobalReview` /
  `aiGlobalDecide`).
- **Global STOP button + live feed + corrections that teach.** New `backend/sdk/ai-control.ts`:
  `ai_paused` kill switch (halts optimizer pass, self-learning, autopublish), `logAiAction`/
  `recentAiActivity` live feed, `recordCorrection` (writes AICorrection + weighted OptimizationSignal +
  AgentLearningMemory so the AI learns from human fixes). New `AILiveOversight.jsx` admin page.
- Compliance/guardrail settings stay excluded via the optimizer `COMPLIANCE_DENYLIST`.
- New settings (`AI_GLOBAL_HUMAN_GATE`, `CHANGE_GLOBAL_MIN_APPROVAL`, `CHANGE_GLOBAL_MIN_SAMPLE`,
  `PEAK_REVIEW_HOUR_UTC`, `PEAK_REVIEW_WINDOW_HOURS`); new entities `AIActivityLog`, `AICorrection`;
  3+2 functions registered.

## 2026-07-29 — Editable KYC survey (AI- and human-adjustable) + self-learning chatbot memory

See `KYC-SURVEY-EDITABLE.md` and `AI-CHATBOT-MEMORY.md`.

- **KYC survey is now stored & editable** (`KycSurveyConfig`), not hardcoded. Human admin editor
  (`KYCSurveyAdmin.jsx` + `kycSurveyAdminGet`/`kycSurveyAdminSave`) and AI adjustment
  (`kycSurveyAISuggest` analyzes real answer distributions → proposal; `kycSurveyProposalDecide`
  approve/reject; `kyc_survey_ai_autopublish` for live AI edits). `validateSurvey` guards every edit.
- **Per-user chatbot memory** (`AssistantMemory`): the catalog assistant remembers each member's
  conversations, distills durable preferences to their individual file, and grounds greetings/replies in
  it — learning and self-improving per user (`backend/sdk/assistant-memory.ts`).

## 2026-07-29 — Marketplace as post-login hub + App Store in Digital Products + onboarding redirect

- **App Store** (the in-app game/app store) is reachable inside **Digital Products** as a **"Digital
  Gaming" subcategory** that opens the existing store page unchanged (no code moved). Nav "Game Store"
  renamed **"App Store."**
- **Marketplace is the post-login hub.** After login, first-time members complete the KYC survey then are
  redirected to the Marketplace; returning members go straight there (logic in `KYCSurveyGate`).
- Marketplace **"buy or browse" intro** wired to the KYC-grounded AI shopping assistant.

## 2026-07-29 — Backend schema audit: 17 missing entity tables added (launch-blocker fix)

The store is table-per-entity, provisioned from `schema.sql`. A full audit found 17 entities used by
this session's features with **no table** (would fail at runtime): `Household`, `Layaway`,
`LiveExperiment`, `LiveAssignment`, `LiveMetricEvent`, `InteractionEvent`, `PointsBoostLedger`,
`SessionCaptureFrame`, `SessionClose`, `UXHeatmapSnapshot`, `UserVariantState`, `AssistantMemory`,
`KycSurveyConfig`, `AIActivityLog`, `AICorrection`, `KYCResponse`, `CatalogBrowseNode`, `CatalogCategory`,
`OverheadReport`, `UXFinding`. All added to `schema.sql` + `entities.json` (idempotent
`CREATE TABLE IF NOT EXISTS`); re-run audit reports zero missing. Run the migrate step on deploy.

## 2026-07-29 — Family & Teens accounts + store sort + one-click Buy now

Storefront + account-structure additions. See `HOUSEHOLD-TEEN-ACCOUNTS.md` and
`STORE-SORT-AND-ONE-CLICK.md`.

- **Store sort control**: Amazon-style sort dropdown at the top of both stores' results (Featured, Price
  Low→High, Price High→Low, Avg. Customer Review, Newest Arrivals, Best Sellers) via a shared
  `src/lib/storeSort.js` (`SORT_OPTIONS` + `applySort`, graceful field fallbacks). Wired into
  `PhysicalStore.jsx` and `DigitalStore.jsx`.
- **One-click "⚡ Buy now"** (`oneClickPurchase`): logs the order immediately in `awaiting_payment`
  (`payment_captured: false`) **without claiming the listing or charging**, then prompts the buyer to
  complete the purchase. Nothing is charged until they confirm and a card is on file (`card_charging`
  stays OFF until processor + legal). Reuses markup, markup-funded welcome credit, and the affordability
  warning; never touches raw card numbers. Buttons + confirm modal added to both store pages.
- **Family & Teens (household/approval) accounts**: new `backend/sdk/household.ts` + six functions
  (`householdCreate`, `householdAddMember`, `householdStatus`, `householdSetLimit`, `householdDecideOrder`,
  `householdRemoveMember`). An adult holder groups members; **teen (13–17) orders route to the adult to
  approve**, or auto-approve under a per-order limit. `purchaseGate` wired into `oneClickPurchase` and
  `purchaseMarketplaceListing` (teen orders open as `pending_approval`, no claim/charge). New
  `src/pages/Household.jsx` + nav entry.
- **Teen enrollment gated OFF**: new `teen_accounts` feature flag defaults **OFF** — adult members work
  today; under-18 enrollment requires verifiable parental consent, minor-data handling, updated legal /
  app-store docs, and counsel sign-off before the flag is turned on. New settings
  `HOUSEHOLD_MAX_MEMBERS` (6), `HOUSEHOLD_TEEN_MIN_AGE` (13).

## 2026-07-28 — Digital Products store (online-only, no BNPL/pickup)

A Digital Products section mirroring the physical store for online-delivered goods. See `DIGITAL-STORE.md`.

- "Digital Products" taxonomy department → serverless-GPU category tiles like every other category.
- `catalog.ts`: `DIGITAL_DEPARTMENT` + `DIGITAL_CATEGORIES` + `isDigitalCategory()`; `physicalStoreConfig`
  now returns `digital_categories` so the Digital store shows only these and the Physical store excludes them.
- `purchaseMarketplaceListing`: digital orders deliver instantly (`delivered` / `digital_delivery`).
  `createMarketplaceListing` accepts `product_type: "digital"`.
- `DigitalStore.jsx`: online-delivery only (no pickup), payment = card (+markup) / points / layaway +
  promo credit + affordability + earn-back tracker; **no Affirm BNPL** (real shippable goods only).
- Flag `digital_store`; nav entry + Marketplace banner (physical + digital side by side).



## 2026-07-28 — Buy Physical Items section (ship/pickup) + payment options + earn-back tracker + layaway

New marketplace section for tangible goods with full parity, serverless-GPU tiles, and the legal,
non-lending versions of "buy now, work it off." See `PHYSICAL-STORE.md`.

- **Section**: "Physical Items" taxonomy department (`taxonomy.ts`) → serverless-GPU category tiles like
  every other category. `PhysicalStore.jsx` page (nav entry + Marketplace banner) with a **Ship vs Local
  Pickup** chooser, search/sort, localized pricing + flag. `fulfillment_mode`/`pickup_location` on listings.
- **Payment options**: credit card default (+10% markup), points/surveys-only, Affirm BNPL, and **Layaway**
  (`layaway.ts`, `layawayStart`/`Contribute`/`Status`) — reserve & pay down with points BEFORE delivery
  (no credit extended); required monthly capped at `LAYAWAY_MAX_MONTHLY_USD` ($90). Welcome credit applied
  per existing rules.
- **Affordability warning**: orders over `PHYSICAL_AFFORDABILITY_LIMIT_USD` ($1,460) warn the buyer before
  they commit (warning, not a block; `purchaseMarketplaceListing` + acknowledgement).
- **Purchase Payback tracker** (`purchasePaybackStatus`): the "negative balance" reframed after
  clarification as a FACTUAL earn-back progress tracker (cash spent vs points earned back) — NOT a loan, no
  money fronted, honest "depends on your activity" copy (no guaranteed payback).
- Flags `physical_store`/`local_pickup`/`layaway`/`purchase_payback`; `physicalStoreConfig` endpoint;
  functions registered.



## 2026-07-28 — Points Boost: closed-loop "your points grow while you hold them" (non-cashable, breakage-funded, self-tuning)

The legal, $0-marginal version of "value goes up → capture the difference as more points." Not crypto,
not an investment — a loyalty mechanic keyed to the user's own behavior. See `POINTS-BOOST.md`.

- **Engine** (`backend/sdk/points-boost.ts`): personal Boost % from streak + tenure + vault (capped at
  `BOOST_MAX_PCT`); balance accrues bonus points; `harvestBoost` credits accrued growth as non-cashable
  points (spendable on-platform only, tagged `boost_promo_points`); `setVault` locks points for a higher
  Boost (reversible, no lock-up risk).
- **Functions**: `pointsBoostStatus`, `pointsBoostHarvest`, `pointsBoostVault`, `autoPointsBoostCredit`
  (scheduled daily auto-harvest). Flag `points_boost`; `PointsBoostLedger` + non-cashable `Transaction`.
- **UI**: `PointsBoostCard.jsx` — live animated ticker (boosted value grows in real time), factor chips,
  Harvest + Vault buttons; mounted on the dashboard.
- **Cost governors**: `BOOST_DAILY_CAP_USD` + `BOOST_LIFETIME_CAP_USD` hard-cap the whole feature's cost
  (breakage-funded ≈ $0); they're on the `COMPLIANCE_DENYLIST` so the AI can never raise them.
- **Self-tuning**: rate knobs (`BOOST_BASE_RATE`, `BOOST_STREAK_RATE`, `BOOST_VAULT_BONUS_PCT`) added to
  optimizer `OPTIMIZABLE` → auto-tuned + live-A/B-tested for engagement through the existing segment
  holdout → significance → guardrail → promote pipeline; `boost_harvest` metric reported.



## 2026-07-28 — Performance & cost optimization pass (keeps every feature, removes cost + risk)

See `PERFORMANCE-AND-COST-OPTIMIZATION.md`. No features removed; each concern became a bounded lever.

- **Incremental counters**: live-experiment monitor reads per-variant counters on the experiment doc
  (CAS-guarded) in O(1) instead of scanning up to 20k `LiveMetricEvent` rows per tick. Scan kept as
  fallback for pre-counter data.
- **Cheap heatmap capture replaces pixel screenshots**: `html2canvas` → tiny structural snapshot
  (viewport, scroll depth, click coords, dead/rage clicks, element boxes; ~1 KB, no image/bucket). New
  `storeSnapshot` + `UXHeatmapSnapshot`; `sessionCaptureAnalyzeBatch` rewritten to **rule-based** analysis
  (dead-click/rage/low-scroll/below-fold CTA), optional single LLM summary only under spend headroom.
- **Coalesced + idle telemetry**: one `telemetryIngest` call now writes both journey rows + aggregate
  (was two client writes); flush on `requestIdleCallback`; unload/background via `fetch({keepalive})` +
  `sendBeacon` fallback; `TELEMETRY_SAMPLE_PCT` session-consistent down-sampling.
- **Caching + fewer writes**: `runningExperiments`/`segmentKeptExperiments` cached ~20s (invalidated on
  create/promote/revert); `UserVariantState` snapshot written only when changed (fingerprint).
- **Delta/wifi OTA**: `capacitor.config` delta + periodic check; `otaUpdate.js` wifi/metered gate via
  `@capacitor/network` (guarded).
- **Kill switch**: `experiments_paused` flag / `LIVE_EXPERIMENTS_PAUSED` setting halts all live
  experimentation with one flip (kept/promoted changes stay).
- **Overhead monitor** (`learningOverheadMonitor`, hourly): watches telemetry/metric/snapshot volume + AI
  spend and auto-throttles within bounds (lowers sample rates over `OVERHEAD_MAX_EVENTS_PER_DAY`; pauses
  experiments at `OVERHEAD_AI_SPEND_PAUSE_PCT` of the AI cap). `OverheadReport` + audit.



## 2026-07-28 — Personalized (segment) learning + segment→site-wide graduation + login/logout lifecycle + OTA live updates

Option (b): AI changes are tested per user-segment first, kept per-user when they win, and graduated
site-wide on a big aggregate bump — applied at next login, no downtime, across web/PWA/native. Plus an
OTA channel so web-layer code reaches installed native apps with no store review. See
`PERSONALIZATION-AND-GRADUATION.md` and `MOBILE-OTA-LIVE-UPDATES.md`.

- **Segment personalization** (`live-experiments.ts` + `personalization.ts`): experiments can be scoped
  to a user segment (behavior + top KYC interest; prefix-matched so base segments cover sub-segments).
  Aggregate significance across the segment is required — no per-single-user noise. Segment winners are
  **promoted as segment-kept** (applied per-user at login via `resolveVariantOverrides`), NOT flipped
  globally.
- **Graduation** (`nominateGraduation` + `runGraduation` + `graduationScan`, scheduled): a segment winner
  with lift ≥ `GRADUATION_LIFT_PCT` opens a site-wide 24h validation experiment; a pass flips it globally
  (no downtime, all platforms). Money/compliance never enter this path.
- **Login/logout lifecycle** (`sessionStart`, `sessionEnd`): login applier resolves + applies the user's
  segment variants (quiet-swap — winners that landed while away apply at next login, never mid-session);
  logout finalizes the session. Wired into `AuthContext` (login/logout) and native `appStateChange`
  (app-resume re-pull).
- **Optimizer wiring**: `OPTIMIZER_SEGMENT_TESTING` (default on) routes non-sensitive proposals to the
  most active segment first. Flag `personalized_learning`; settings `GRADUATION_LIFT_PCT`/
  `SEGMENT_MIN_SAMPLE`. `graduationScan` scheduled every 2h.
- **OTA live updates** (`src/lib/otaUpdate.js`, `native.js`, `capacitor.config.json`): guarded
  `@capgo/capacitor-updater` integration (no-op until installed) that pushes web-bundle updates to
  installed native apps with **no store review**; app-resume checks for updates. `APP-STORE-SUBMISSION-
  CHECKLIST.md` now documents that ongoing changes are store-review-free.



## 2026-07-28 — Live experimentation: 24h test → promote-if-better, bandit, circuit breaker, canary, per-user quiet-swap

Added a live-experiment layer so AI-proposed changes are tested on real traffic and promoted only if the
data agrees — with no downtime (see `LIVE-EXPERIMENTATION.md`). Built on the existing optimizer +
settings/flags; money/compliance stays human-gated.

- **Engine** (`backend/sdk/live-experiments.ts`): a change is a config value read at request time, so
  promote/revert is a flip (no downtime). Deterministic **sticky per-user assignment** with **quiet-swap**
  (users only bucketed at a session boundary / while inactive). **Two-proportion significance test** +
  normal-approx posterior. **Thompson-style bandit** traffic-shift. **Guardrail circuit breaker** (instant
  halt on refund/complaint/drop-off regression). **Canary ramp** 5→25→50→100%. Promotion via `setSetting`
  (setting/flag) or a `UIVARIANT_*` row (UI). Opt-out honored.
- **Functions**: `liveExperimentCreate`, `liveVariants` (request-time applier + exposure),
  `recordVariantMetric` (outcome/guardrail), `liveExperimentTick` (scheduled real-time monitor:
  measure→breaker→bandit→canary→promote/expire), `liveExperimentPromote` (manual), `liveExperimentStatus`
  (dashboard). Scheduled `liveExperimentTick` every 10 min.
- **Optimizer wiring** (`optimizer.ts`): non-sensitive proposals now route to a live holdout; sensitive/
  price stay on the human-approval path. Flag `live_experiments` + `OPTIMIZER_LIVE_TEST`/
  `LIVE_TEST_WINDOW_HOURS`/`LIVE_TEST_START_SHARE` settings.
- **Frontend**: `src/lib/liveVariants.js` (fetch-once-per-session applier + `reportMetric`) and
  `VariantProvider`/`useVariant`. `Marketplace.jsx` wired as the reference adoption (buy-CTA variant +
  `purchase`/`click_through` reporting). No new paid deps; monitor is cheap aggregate math under the AI cap.



## 2026-07-28 — KYC survey, catalog first-view chatbot, telemetry + sampled capture, self-learning loop

Added the AI data + self-learning package, all default-safe and built on the existing engines
(optimizer, experiment/A-B pipeline, session recorder, site-model grounding, welcome-credit):

- **Know-Your-Customer survey** (`backend/sdk/kyc.ts`, `kycSurveyGet`, `kycSurveySubmit`,
  `src/components/onboarding/KYCSurveyGate.jsx`): the mandatory first survey after first login. Gates
  the app until completed, captures interests, and grants a **$5 non-cashable** reward (tops up the
  welcome-rewards pool; per-order cap + expiry apply — $0 cash via breakage). `kyc_survey` flag +
  `KYC_SURVEY_REQUIRED`/`KYC_REWARD_USD` settings.
- **Catalog first-view chatbot** (`catalogAssistantChat`,
  `src/components/marketplace/CatalogWelcomeChat.jsx`): greets a member the first time they open the
  marketplace and asks what they want, grounded in their KYC answers + real catalog listings.
- **Interaction telemetry + statistics** (`backend/sdk/telemetry.ts`, `telemetryIngest`,
  `telemetryStats`; extends `src/lib/uxTracker.js` with scroll depth + a telemetry feed): every
  interaction is a data point (default-on, ~free), rolled into funnel/scroll/drop-off statistics and
  published as `OptimizationSignal`s the site model + optimizer already consume. `site_telemetry` flag.
- **Sampled, budget-capped session screenshots** (`backend/sdk/session-capture.ts`,
  `sessionCaptureIngest`, `sessionCaptureAnalyzeBatch`): a rotating **fraction** of sessions (not
  everyone) is captured to the low-cost bucket and analyzed in batches under
  `SESSION_CAPTURE_DAILY_BUDGET_USD` / `AI_DAILY_SPEND_CAP_USD`. **OFF by default** (`session_screenshots`
  flag). Disclosed in the privacy policy; opt-out honored; PII masked.
- **Self-learning loop** (`selfLearningCycle`, scheduled): collect + analyze telemetry/capture/KYC →
  refresh the site model → propose small, statistically-backed changes → A/B test each with a customer
  survey (existing experiment pipeline) → deploy customer-favored winners. Money/compliance stays
  human-gated. Gated on `SELF_LEARNING_MIN_SAMPLE` so changes stay small, iterative, and correlated.
- Scheduled `telemetryStats`, `sessionCaptureAnalyzeBatch`, and `selfLearningCycle` in
  `backend/scheduler/schedules.json`. No new paid dependencies — launch cost unchanged; the only cost
  lever (full screenshot capture) ships off + sampled.



Two zips (your local "final 2" and the GitHub `main`) were confirmed **byte-for-byte identical**, so these changes apply cleanly to either.

> **Note on "identical yet buggy":** the two zips matching each other only means your local copy and GitHub are the same code — not that the code is correct. Both copies shared the *same* latent gaps (missing backend functions, missing entity schemas, a dead link). Comparing the zips tells you they match; auditing the code is what surfaced the real errors below.

## 1. Three "coming soon" features implemented

### StreamerAnalytics — Demographics tab
`src/pages/StreamerAnalytics.jsx`
Replaced the "Demographic data coming soon" placeholder with a working audience-demographics view built from real data (spectator engagement + subscriber/User profiles):
- Summary cards: audience size, top location, new (30d), returning
- Top viewer locations (horizontal bar, from profile/engagement country)
- Watch-time distribution (bucketed from spectating sessions)
- Audience composition (new vs returning pie)
- Graceful empty state when there's no audience data yet

### SurveyMarketplace — Response flow
`src/pages/SurveyMarketplace.jsx`
Replaced the "Feature coming soon" toast with a real response dialog:
- Micro-surveys render each question by type (multiple choice, yes/no, rating stars, open text) with validation
- Trades/swaps show a confirmation with an optional message to the creator
- On submit: increments the listing's response count (auto-completes when full), credits the respondent's reward via a `Transaction` (`survey_earning`), and notifies the creator via `Notification`
- Soft client-side guard prevents responding twice / to your own listing

### Settings — Change password
`src/pages/Settings.jsx`
Replaced the "coming soon" toast with a real flow:
- Added a confirm-password field, strength hint, and inline mismatch warning
- Validates length (8+), letters+numbers, new ≠ current, confirmation match
- Feature-detects a password method on the auth SDK; since this app uses hosted/social sign-in, it falls back to routing the user to the secure provider page to update their password

## 2. AI audit — gaps found and fixed

Scanned the full AI layer: **73 agents**, **~504 backend functions**, AI entities, and all frontend AI wiring.

### Missing backend functions the frontend was calling (would fail at runtime) — CREATED
These 6 were invoked via `base44.functions.invoke(...)` but had no implementation:

| Function | Called from | What it now does |
|---|---|---|
| `aiDisputeEvidenceAnalyzer` | AIDisputeAutomationDashboard | LLM-scores a dispute claim + platform evidence, returns a recommendation |
| `businessClientReengagementEngine` | BusinessClientReengagementDashboard | Finds inactive business clients, drafts `RetentionCampaign`s for approval |
| `buyContestPowerUp` | HeadToHeadContest | Deducts virtual currency, records a `ContestPowerUp` |
| `exportAIData` | AIContentHub | Aggregates the user's AI data into a downloadable JSON payload |
| `trackAdClick` | PPCAdSearchWidget | Increments an ad listing's click count + logs the click |
| `viralContentGenerator` | ViralContentDashboard | LLM-generates viral `SocialMediaPost`s for review (with template fallback) |

### Agent-referenced gaps — CREATED
- `banAppealScorer` (backend function): referenced by `universal_admin_action_agent`; now scores ban appeals via LLM + user history.
- `Survey` (entity): **used by 5 frontend components** (incl. AI `PersonalizedRecommendations`, plus RevenueTracker, RevenueDistribution, LockoutModal, PointsBadgeSystem) but had no definition. Added `base44/entities/Survey.jsonc` with fields derived from actual usage (`user_id`, `earnings`, `completion_date`, `status`, `category`, `title`, `reward_amount`, …).

### Informational (no change made)
- `test_backend_function` is referenced by `automation_guardian`. This is Base44's built-in function-testing tool, not a custom function — no action needed.

## 3. Navigation wiring

The new backend functions are called by existing pages. Most of those pages were already in the menu (AIContentHub, HeadToHeadContest, and the PPC ad widget). Three admin dashboards that are now functional were **not linked anywhere**, so I added them to the admin-only section of the floating sidebar (`src/components/nav/FloatingNavSidebar.jsx`, `ADMIN_NAV_SECTION` — only shown to `role === 'admin'`):

- **Viral Content AI** → `ViralContentDashboard`
- **AI Dispute Automation** → `AIDisputeAutomationDashboard`
- **Client Re-engagement** → `BusinessClientReengagementDashboard`

I intentionally did *not* add these to the general header menu in `Layout.jsx`, which has no admin gating — showing admin-only links to every signed-in user would just lead them to an "Admin access required" screen.

## 4. Deep audit (round 2) — additional errors found & fixed

After a broader pass (every entity reference, every import, every page link — not just function calls):

**More missing entity schemas (would break features at runtime) — CREATED**
- `MarketTrendReport` — used by `CompetitiveMonitoringDashboard` and written by `aiCompetitiveIntelligenceEngine`; no schema existed.
- `PerformanceAlert` — created by `affiliatePerformanceMonitoring` (the code even had a "entity might not exist yet, skip" guard); no schema existed.
- `RespondentProfile` — read by `notifyNewSurveyMatch` and `calculateTrustScore`; no schema existed. (Note: a `RespondentProfile` *page* exists — that's separate from the entity.)

**Dead navigation link — FIXED**
- `src/components/pricing/WhiteLabelSection.jsx` linked "View Partner Dashboard" to a non-existent `PartnerPortal` page. Repointed to the real `PartnerOnboarding` page.

**Clean (verified, no issues):**
- All local imports resolve to real files (0 broken).
- All `createPageUrl(...)`, `<Link to>`, and `window.location.href` targets resolve to real pages (0 dead, after the fix above).
- All `base44.entities.X` references — frontend **and** backend — now resolve (0 missing).
- All `base44.functions.invoke(...)` calls resolve (0 missing).

## 5. Data-driven growth loop, translation/currency & secrets (round 3)

### Weekly mandatory $0.10 feature/game vote → auto-implementation pipeline (NEW)
Users vote each week on which games/features to build; the winner is correlated, ranked, spec'd, and handed to the auto-implementation planner.

- `base44/entities/FeatureVoteSurvey.jsonc` — the weekly survey (candidates, votes, mandatory flag, $0.10 reward, winner, spec).
- `base44/functions/generateWeeklyFeatureVoteSurvey/entry.ts` — builds the weekly survey from top `UserSuggestion`s + pending `FeatureMockup`s and notifies active users.
- `base44/functions/submitFeatureVote/entry.ts` — records votes, credits $0.10 once, blocks double-voting.
- `base44/functions/concludeWeeklyFeatureVote/entry.ts` — tallies responses, ranks by votes, picks the winner, generates an implementation spec, records a `FeatureMockup`, and calls the existing `aiAutomaticFeatureImplementation`.
- `src/pages/WeeklyFeatureVote.jsx` — the voting page (mandatory banner, multi-select, reward). Routed in `App.jsx`; linked in the sidebar's "Earn" group.
- `base44/agents/feature_vote_growth_agent.jsonc` — runs the weekly cadence (generate → collect → conclude → implement).

> **Boundary — important:** this pipeline collects demand, ranks it, and produces a developer-ready **implementation spec**, then hands it to `aiAutomaticFeatureImplementation`, which classifies items as *auto-deploy* vs *manual review*. It does **not** blindly write and deploy arbitrary code to your live app — anything touching payments, auth, or payouts is always flagged for human review. Final code for a winning feature is executed via the Base44 builder or a developer from the generated spec. Fully autonomous self-coding of any feature is intentionally **not** enabled, for safety.

### Translation & currency — already present (confirmed), and user-accessible
You were right: this is already built. AI language translation (`translateText`, `multilingualTranslator`, `useTranslation`, auto browser-language detect) and **currency conversion with live exchange rates** (`LocaleContext`, 10 currencies, hourly rates from exchangerate-api.com with fallback) both exist, the providers are mounted, and both selectors are exposed to users in **Settings → Language**. No change was needed. (Note: `formatCurrency`/`useTranslation` are currently applied on only a few pages, so many prices/labels still render in raw USD/English — broadening that across all pages is optional incremental work, not a missing capability.)

### API keys / secrets / auth — see `CONFIG-AND-SECRETS.md`
Full scan found **no secrets stored in the code** (correct, secure design — all via env vars in Base44's secret manager). `CONFIG-AND-SECRETS.md` lists every key the app *expects* (names only) so you know what to configure. Nothing sensitive was extracted or published.

## 6. Self-running ecosystem layer (round 4)

Goal: let the platform grow itself from survey data — internal surveys, **external company surveys** (PPC + BitLabs), feature votes, and suggestions — turning demand into AI-generated games, features, services, and content.

Rather than duplicate the substantial self-running backbone that already exists (`masterOrchestrator` every 6h, `aiOrchestrator` every 12h, daily/hourly/weekly engines, 5 domain super-agents), I added the **connective layer** that ties survey data → AI creation → implementation:

- `base44/entities/EcosystemConfig.jsonc` — master switch + settings: `autonomous_mode`, `active_pillars`, `cadence_hours`, `auto_deploy_enabled`, `human_review_categories`, `min_signal_threshold`, run counters.
- `base44/entities/EcosystemRunLog.jsonc` — an audit record of every cycle (snapshot ingested, AI insights, what was generated, actions, errors).
- `base44/functions/autonomousEcosystemEngine/entry.ts` — the master loop: ingests demand from **all** survey sources, generates AI insight on what to build next, then acts per pillar by delegating to your existing generators (`generateAISurvey`, `aiGameCreatorFromFeedback`, `autoFeedbackAndProductEngine`, `publishWinningSurveyProduct`, `aiGenerateContentLibrary`, the weekly feature-vote loop), and hands ongoing ops to `masterOrchestrator` + `aiOrchestrator`. Logs every run.
- `base44/agents/autonomous_ecosystem_superagent.jsonc` — the top-level agent that runs the loop on cadence.

### The autonomy boundary (important, and by design)
The engine **generates and queues** work; it does not silently write and deploy arbitrary production code. Anything in `human_review_categories` (payments, auth, payouts, security) is **always** flagged `requires_review` and never auto-deployed. `auto_deploy_enabled` only affects clearly low-risk items. Every cycle is logged for auditability. This is the responsible ceiling for a live, money-handling platform: fully autonomous self-coding of any feature/service is intentionally not enabled — a winning idea produces a spec + queued plan that the Base44 builder or a developer executes. To turn the loop on, set `EcosystemConfig.autonomous_mode = true` and schedule `autonomousEcosystemEngine` (daily), or run it once with `{ "force": true }`.

### Backend completeness — verified
Final whole-project audit: **0 missing** function calls (frontend + backend-to-backend, 95 distinct backend calls checked), **0 missing** entity references (frontend + backend), **0** unresolved agent references (aside from Base44's built-in `test_backend_function`), and **0** function folders without an `entry.ts`. The one flagged item (`aiGameRecommendationEngine`) appears only in a markdown doc, not in code.

## 7. Weekly rotating-platform referral contest (round 5)

A mandatory weekly referral posting contest that rotates the required social platform each week.

**Assumptions locked in (correct any):** platform rotates weekly Twitter/X → Instagram → Facebook → TikTok → LinkedIn; **$0.10 per post held pending and credited on the user's next survey completion**; if a user misses a week, their next assignment **doubles up to 2 posts on their best-performing platform** (highest conversion/return rate from their own data); business vs. user referrals on **separate leaderboards**; standard 5% affiliate commission still applies to real conversions.

- `base44/entities/WeeklyReferralCampaign.jsonc` — the weekly campaign (rotation platform, mandatory flag, $0.10 reward, two-track leaderboards, close time).
- `base44/entities/ReferralPostEntry.jsonc` — each user post (platform, track, proof URL, `was_doubled`, pending/credited reward, conversions, commission).
- `base44/entities/UserPlatformStats.jsonc` — per-user per-platform performance; drives the "best platform" pick for doubled assignments.
- `base44/functions/generateWeeklyReferralCampaign/entry.ts` — weekly: rotates platform by week index, creates the campaign, notifies users.
- `base44/functions/submitReferralPost/entry.ts` — logs a post; computes the assignment (doubling on the best platform if last week was missed), records the pending $0.10, tags business vs. user, updates platform stats.
- `base44/functions/creditPendingReferralPostRewards/entry.ts` — credits pending post rewards; **wired into survey completion** (called from `submitFeatureVote`).
- `base44/functions/concludeWeeklyReferralCampaign/entry.ts` — closes the week, builds business + user leaderboards.
- `src/pages/WeeklyReferralContest.jsx` — the page (this week's platform, mandatory banner, submit-post form, pending-reward status, leaderboards). Routed + in the sidebar's "Earn" group.
- `base44/agents/weekly_referral_campaign_agent.jsonc` — runs the weekly cadence.

## 8. Compliance corrections + daily end-to-end referral automation (round 6)

**Corrected assumptions** (full detail in `COMPLIANCE-AND-ASSUMPTIONS.md`) on profitability/legality/ethics/best-practice grounds:
- "Mandatory" survey & posting → **opt-in / voluntary** (removed coercion; `is_mandatory` defaults false; copy reworded).
- Referral posts now require an **FTC #ad disclosure**.
- Auto-posting to personal accounts happens **only** for OAuth-connected, opted-in, agreement-accepted users (via your existing compliant path), rate-limited — never forced/silent posts for others.
- $0.10 rewards are now **never forfeited**: a daily grace-period sweep auto-credits anything pending > 30 days.
- "Miss a week → doubled" reframed as an **optional double bonus**, not a penalty.
- Flags left for your/legal decision: MLM/pyramid rules, paid-review rules, GDPR/CCPA data privacy, sweepstakes/contest law, 1099/money-transmission.

**Daily end-to-end automation (NEW):** `base44/functions/autoReferralContestDaily/entry.ts` runs the entire contest every day — rotates/rolls the weekly platform, compliantly auto-posts for opted-in connected users (with #ad), reminds everyone else (optional), sweep-credits pending rewards, concludes finished weeks, and logs each run to `EcosystemRunLog`. The `weekly_referral_campaign_agent` now runs this daily with the guardrails as hard rules.

## 9. Gambling → skill-based tournament (round 7)

The only true gambling mechanic was the weekly **jackpot**, which picked a winner by **random draw**. Converted to a skill-based tournament with entry fee + prize pool:
- `base44/functions/processWeeklyJackpot/entry.ts` — rewritten: winners **ranked by performance**, prize pool split among top finishers (50/30/20), **no `Math.random`**.
- `base44/functions/enterSkillTournament/entry.ts` — **NEW**: pay an entry fee → funds the prize pool.
- `base44/entities/ReferralJackpot.jsonc` — reframed as a skill tournament (`is_skill_based`, `entry_fee`, `prize_pool`, `payout_places`, `winners[]`); name kept for compatibility.
- UI de-gambled: `JackpotWidget.jsx`, `ReferralMilestoneJackpot.jsx`, `ContestEntries.jsx` — "Win Chance %"/"Your Chances" → "Point Share"/"Ranked By: Skill"; "Active Jackpot" → "Active Skill Tournament".
- `weeklyContestWinner` was already skill-based (no change). See `COMPLIANCE-AND-ASSUMPTIONS.md` §7 for the legal note on entry-fee skill contests by state.

**Round 7b — refined into an open, merit-based, self-funding reward** (`COMPLIANCE §7a`): `processWeeklyJackpot` now pays **everyone in proportion to the verified, revenue-generating referrals they drive** (70% proportional to all + 30% top-3 bonus), gated to **verified conversions only** (anti-fraud), with the pool funded as a **share of the real revenue those referrals produced** (default 40%, platform keeps ~60% margin). Open to all, no entry fee required, zero chance. `ReferralJackpot` gained `open_to_all`, `pool_funding_rate`, `distribution_model`, `revenue_driven`, `verified_conversions`; widget copy updated.

## 10. Rename: "Jackpot" / "Referral Contest" → "Prize Pool" (round 8)

User-facing terminology renamed across the app (display text only — internal identifiers like the `ReferralJackpot` entity, `JackpotWidget` component, function names, and tab-state keys are unchanged so nothing breaks):
- "Jackpot" → "Prize Pool"; "Jackpot Entries/Entry" → "Prize Pool Points/Point".
- "Referral Contest" → "Referral Prize Pool" (nav labels, page headings, badges).
- Slot-machine 🎰 emoji (gambling imagery) → 🏆 everywhere.
- Push/toast titles ("Jackpot Alert" → "Prize Pool Alert"), milestone perks, "How the Prize Pool Works" box rewritten to the merit-based framing.
- ~74 replacements across 38 files; all pass syntax checks. No entity/function/route renames (safe).

## 11. Shared wallet groups (family pools) (round 9)

Users can form groups (family/friends/team), pool credits toward large-ticket items, and transfer to each other — e.g., a family of four pooling ~$120/month.
- Entities: `SharedWalletGroup` (name, type, owner, members, invite code, monthly goal, pooled balance), `GroupContribution`, `GroupSpendRequest`. (Note: the existing `UserGroup` entity is a 100k-user game-rotation shard — deliberately not reused.)
- Functions: `createSharedWalletGroup`, `joinSharedWalletGroup` (invite code), `contributeToGroup` (moves credits from member balance into the pool), `requestGroupSpend` (large-ticket purchase or member transfer; owner executes immediately, members create a pending request), `approveGroupSpend` (owner approves/rejects & executes).
- Page: `SharedWalletGroups.jsx` — create/join, pool + monthly-goal progress, contribute, copy invite code. Routed + in the sidebar's Account group.
- **Money uses closed-loop platform credits, not external cash** (lower regulatory risk); spending is owner-approved and capped by the pool. See `COMPLIANCE-AND-ASSUMPTIONS.md` flags for money-transmitter/escrow considerations before enabling real-cash pooling.

## 12. Mobile app wrapper — Android & iOS (Capacitor)

Wrapped the PWA for the app stores (config committed to the repo; native build runs on your machine):
- `capacitor.config.json` — app id `com.playearningnexus.app`, `webDir: dist`, splash/theme.
- `package.json` — Capacitor deps (`@capacitor/core|android|ios|app|cli|assets`) + `cap:*` scripts.
- `public/manifest.json` — the previously-missing PWA manifest (icons, standalone, theme).
- `index.html` — mobile/PWA meta tags (theme-color, iOS standalone, apple-touch-icon).
- `MOBILE-APP-WRAPPER-GUIDE.md` — full step-by-step: install → generate icons → add android/ios → build → sign → submit to Play Store & App Store, plus a PWABuilder zero-code alternative and app-store-review caveats (Apple 4.2, earning/payment rules).
- Native project generation and store builds must run on your machine (iOS needs a Mac + Xcode); those can't run in the cloud.

## 13. App icons + Privacy Policy & Terms (legal pages)

- **Placeholder icon set** generated: `public/icons/icon-192.png`, `icon-512.png`, `icon-512-maskable.png`, `apple-touch-icon.png`, and `assets/icon.png` (1024 source). Swap for your real brand icon and re-run `npm run cap:assets`.
- **In-app legal pages** (public, render without login — required by app stores): `src/pages/PrivacyPolicy.jsx` → `/PrivacyPolicy`, `src/pages/TermsOfService.jsx` → `/TermsOfService`. Routed in `App.jsx`, linked in the sidebar Account section, cross-linked to each other.
- **Standalone docs:** `PRIVACY-POLICY.md`, `TERMS-OF-SERVICE.md` (same content), plus `LEGAL-PAGES-GUIDE.md` explaining placeholders and store requirements.
- These legal docs are **templates tailored to this app** (surveys, earnings, referrals, skill contests, wallet groups) and **must be reviewed by a lawyer**; fill the `[BRACKET]` placeholders in both the pages and the .md files.
- **Native apps:** Capacitor already unifies the PWA and native shells (one web codebase → both). The `android/`/`ios/` project folders are generated on your machine via `npx cap add ...` (iOS needs a Mac) — that step can't run in the cloud.

## 14. Wrapper-only native architecture (no committed native folders)

Reworked the mobile wrapper so the repo stays wrapper-only — there are **no `android/`/`ios/` project files in git**:
- `.gitignore` now excludes `/android`, `/ios`, `.gradle`, `*.keystore`, `.capacitor` — native folders are generated build artifacts, never committed.
- `src/lib/native.js` — native behavior (status bar, splash hide, Android back button) implemented in the **web/TS layer** via Capacitor plugins, guarded by `isNativePlatform()` (no-ops on web). Initialized from `src/main.jsx`. No hand-written native code to maintain.
- `scripts/regenerate-native.sh` + `npm run native:regenerate` — one command rebuilds the native shells from the wrapper on demand (`cap add` if missing + `cap sync`), then you open in Android Studio/Xcode.
- `package.json` — added `@capacitor/status-bar` + `@capacitor/splash-screen`; replaced the `cap:add:*` scripts with `native:regenerate`.
- Guide updated to explain the wrapper-only model and the trade-off (commit native folders only if you ever need custom native source).

## ⚠️ One thing to reconcile
If your live Base44 backend **already defines a `Survey` entity** (it may simply have been excluded from the export), do not import the new `Survey.jsonc` on top of it — reconcile the schemas instead. Everything else is purely additive and safe to merge.

## Validation
- All 205 pages present and routed (unchanged).
- All 73 agents parse; all agent function/entity references now resolve (except the built-in `test_backend_function`).
- 0 frontend-invoked functions missing after fixes.
- All 3 modified pages and 7 new `.ts`/entity files pass syntax checks.

## Files changed (24)
```
# Rounds 1-2 (features, AI audit, deep audit)
M  src/pages/StreamerAnalytics.jsx
M  src/pages/SurveyMarketplace.jsx
M  src/pages/Settings.jsx
M  src/components/nav/FloatingNavSidebar.jsx
M  src/components/pricing/WhiteLabelSection.jsx
A  base44/entities/Survey.jsonc
A  base44/entities/MarketTrendReport.jsonc
A  base44/entities/PerformanceAlert.jsonc
A  base44/entities/RespondentProfile.jsonc
A  base44/functions/aiDisputeEvidenceAnalyzer/entry.ts
A  base44/functions/businessClientReengagementEngine/entry.ts
A  base44/functions/buyContestPowerUp/entry.ts
A  base44/functions/exportAIData/entry.ts
A  base44/functions/trackAdClick/entry.ts
A  base44/functions/viralContentGenerator/entry.ts
A  base44/functions/banAppealScorer/entry.ts

# Round 3 (data-driven growth loop + docs)
M  src/App.jsx
A  src/pages/WeeklyFeatureVote.jsx
A  base44/entities/FeatureVoteSurvey.jsonc
A  base44/functions/generateWeeklyFeatureVoteSurvey/entry.ts
A  base44/functions/submitFeatureVote/entry.ts
A  base44/functions/concludeWeeklyFeatureVote/entry.ts
A  base44/agents/feature_vote_growth_agent.jsonc
A  CONFIG-AND-SECRETS.md
(src/components/nav/FloatingNavSidebar.jsx also updated again for the vote link)

# Round 4 (self-running ecosystem layer)
A  base44/entities/EcosystemConfig.jsonc
A  base44/entities/EcosystemRunLog.jsonc
A  base44/functions/autonomousEcosystemEngine/entry.ts
A  base44/agents/autonomous_ecosystem_superagent.jsonc

# Round 5 (weekly rotating-platform referral contest)
A  src/pages/WeeklyReferralContest.jsx
A  base44/entities/WeeklyReferralCampaign.jsonc
A  base44/entities/ReferralPostEntry.jsonc
A  base44/entities/UserPlatformStats.jsonc
A  base44/functions/generateWeeklyReferralCampaign/entry.ts
A  base44/functions/submitReferralPost/entry.ts
A  base44/functions/creditPendingReferralPostRewards/entry.ts
A  base44/functions/concludeWeeklyReferralCampaign/entry.ts
A  base44/agents/weekly_referral_campaign_agent.jsonc
M  base44/functions/submitFeatureVote/entry.ts  (now also credits pending referral rewards)
(src/App.jsx and FloatingNavSidebar.jsx updated again for the referral page)
```

<!-- last synced to remote: 2026-07-29 (GamerGain 9) -->
